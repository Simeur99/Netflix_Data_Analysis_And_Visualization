# Load necessary libraries
library(ggplot2)
library(readr)

#load the dataset
df <- read_csv("netflix_data/Netflix_shows_movies.csv")  # Adjust path as needed

# Count ratings
rating_counts <- as.data.frame(table(df$rating))

# Rename columns
colnames(rating_counts) <- c("Rating", "Count")

# Plot ratings distribution
ggplot(rating_counts, aes(x = reorder(Rating, Count), y = Count)) +
  geom_bar(stat = "identity", fill = "gold") +
  coord_flip() +
  labs(title = "Ratings Distribution",
       x = "Rating",
       y = "No of Ratings") +
  theme_minimal()